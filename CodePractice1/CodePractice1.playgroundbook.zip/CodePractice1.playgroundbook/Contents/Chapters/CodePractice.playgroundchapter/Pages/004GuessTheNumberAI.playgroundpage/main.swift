//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
/*:
 # 猜数字AI版
 
输入一个三位以内的数字，AI不断的猜测数字，显示出猜测的次数和数字以及是大了或是小了，看看你写的程序需要用多少次才能猜中，看看谁写出来的AI最聪明！

判断、循环、递归、数字和字符串处理练习，也许你可以试试递归
*/
