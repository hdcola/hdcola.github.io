//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
/*:
有四个数字：1、2、3、4，能组成多少个互不相同且无重复数字的三位数？各是多少？

说明：

可填在百位、十位、个位的数字都是1、2、3、4。组成所有的排列后再去 掉不满足条件的排列。

判断、循环、数字、字符串处理练习。
 
 ```
let name = "Rosa"
let personalizedGreeting = "Welcome, \(name)!"
// personalizedGreeting == "Welcome, Rosa!"
let price = 2
let number = 3
let cookiePrice = "\(number) cookies: $\(price * number)."
// cookiePrice == "3 cookies: $6."
 let longerGreeting = greeting + " We're glad you're here!"
 // longerGreeting == "Welcome! We're glad you're here!"
 ```
 */
