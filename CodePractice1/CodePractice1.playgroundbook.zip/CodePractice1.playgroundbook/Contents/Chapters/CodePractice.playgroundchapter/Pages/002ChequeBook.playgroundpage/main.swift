//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
/*:
在村儿里生活需要手写支票，让我们写个程序将一个数字转换成为英文大写。需要支持到百万和小数点后两位。

说明：

1-21; 30; 40; 50; 60; 70; 80; 90; 100; 1,000; 10,000; 100,000; 1,000,000的英文写法如下：

One, Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Eleven, Twelve, Thirteen, Fourteen, Fifteen, Sixteen, Seventeen, Eighteen, Nineteen, Twenty, Twenty-one, Thirty, Forty, Fifty, Sixty, Seventy, Eighty, Ninety, One Hundred, One Thousand, Ten Thousand, One Hundred Thousand, One Million

写完整数后，要加上 Dollars。当有小数点时，小数点写为 and ，小数点后的会写为 xxx Cents。

举例： 175.25$ one hundred seventy five dollars and twenty-five cents

判断、循环、递归、数字和字符串处理练习，也许你可以试试递归
*/
