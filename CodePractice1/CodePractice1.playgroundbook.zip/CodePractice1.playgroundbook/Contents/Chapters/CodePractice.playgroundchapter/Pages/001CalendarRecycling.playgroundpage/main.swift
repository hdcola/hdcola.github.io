//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
/*:
输入某年某月某日（例：20190205），判断这一天是这一年的第几天？

说明：

以3月5日为例，应该先把前两个月的加起来，然后再加上5天即本年的第几天，特殊情况，闰年且输入月份大于2时需考虑多加一天。另外，自己Google一下，怎么识别闰年和闰年与非闰年的区别。

判断、循环、数字、字符串处理练习。

字符串是可以变为数字的

```
let s = "20191209"
let n = Int(s)
```
*/
