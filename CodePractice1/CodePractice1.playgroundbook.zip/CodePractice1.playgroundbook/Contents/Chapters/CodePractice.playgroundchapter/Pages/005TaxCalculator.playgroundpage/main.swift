//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
/*:
 加拿大的个人所得税分为联帮个人所得税和各省各自征收的个人所得税。以下是2019年的所得税税率
 
 联邦个人所得税率：47,630$以下为15%；47,630-95,259$为26%；147,667-210,371$为29%；210,371$以上为33%。
 
 Quebec省个人所得税率：43,790$以下为15%；43,790-87,575$为20%；87,575-106,555$为24%;106,555$以上为25.75%。
 
 请先输入一个年收入的数字，分别计算出联帮所有税、魁省所得税和要交的税收总额。
 
 判断、循环、数字处理练习，试试数组吧
*/
