//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
/*:
经典的猜数字游戏，随机生成一个三位以内的数字作为答案。用户输入一个数字，程序会提示大了或是小了，直到用户猜中。记得提示用户猜中了多少次，看看谁用的次数少！

判断、循环、递归、数字和字符串处理练习
*/
let randomNumber = Int.random(in: 0...999)
