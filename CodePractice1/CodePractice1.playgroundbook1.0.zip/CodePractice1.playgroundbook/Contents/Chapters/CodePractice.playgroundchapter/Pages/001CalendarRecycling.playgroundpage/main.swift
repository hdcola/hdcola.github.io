//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
/*:
输入某年某月某日（例：20190205），判断这一天是这一年的第几天？

说明：

以3月5日为例，应该先把前两个月的加起来，然后再加上5天即本年的第几天，特殊情况，闰年且输入月份大于2时需考虑多加一天。对于闰年的判断如下：
 
 - 该年能被 4 整除吗？
    - 如果能，该年能被 100 整除吗？
        - 如果不能，该年是闰年。
        - 如果能，该年能被 400 整除吗？
            - 如果不能，那么它**不是**闰年。
            - 如果能，那么该年是闰年。

判断、循环、数字、字符串处理练习。

字符串是可以变为数字的，将一个字符串转换为数字时如果无法转换需要使用`?? 0`这样，为它设置一个缺省值。

```
let s = "20191209"
let n = Int(s) ?? 0
```
*/
