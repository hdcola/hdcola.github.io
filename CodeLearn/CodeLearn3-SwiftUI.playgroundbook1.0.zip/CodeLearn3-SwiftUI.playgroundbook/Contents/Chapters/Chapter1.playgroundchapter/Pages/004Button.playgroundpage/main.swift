/*:
 为了响应输入，我们来试试Button组件，试试用之前的Stack布局一个iPhone上的计算器键盘。
 */
import Foundation
import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    var body: some View {
        Button(action: {
            print("tap +")
        }){
            Text("+")
                .font(.system(size: 38))
                .foregroundColor(.white)
                .frame(width: 88, height: 88)
                .background(Color.orange)
                .cornerRadius(44)
        }
    }
}

PlaygroundPage.current.setLiveView(ContentView())
