/*:
Swift提供了枚举(enum)为一组相关的值定义了一个共同的类型，使你可以在你的代码中以类型安全的方式来使用这些值。我们来使用enum再次简化计算器的布局。同时我们会学到一个新的switch语句进行多种可能的判断，相比if来讲，它更适合enum配套使用。最后试着把所有的键盘按键都加入界面中去。
*/
import Foundation
import SwiftUI
import PlaygroundSupport

enum CalculatorButtonItem {
    enum Op: String {
        case plus = "+"
        case minus = "-"
        case divide = "÷"
        case multiply = "×"
        case equal = "="
    }
    enum Command: String {
        case clear = "AC"
        case flip = "+/-"
        case percent = "%"
    }
    case digit(Int)
    case dot
    case op(Op)
    case command(Command)
}

// 扩展enmu，支持Hashable用于在View支持ForEach
extension CalculatorButtonItem: Hashable {
    var title:String{
        switch self {
            case .digit(let value): return String(value)
            case .dot: return "."
            case .op(let op): return op.rawValue
            case .command(let command): return command.rawValue
        }
    }
    var backgroundColor:Color{
        switch self {
            case .digit,.dot: return Color.blue
            case .op: return Color.orange
            case .command: return Color.secondary
        }
    }
}

struct ContentView: View {
    let rows: [CalculatorButtonItem] = [.digit(1), .digit(2), .digit(3), .op(.plus)]
    
    var body: some View {
        HStack{
            ForEach( 0..<rows.count ){ index in
                CalculatorButton(title: self.rows[index].title,backgroundColor: self.rows[index].backgroundColor, action: {
                    print("tap \(self.rows[index].title)")
                })
            }
        }
    }
}

struct CalculatorButton: View{
    let title: String
    let backgroundColor: Color
    let action: () -> Void
    
    var body: some View{
        Button(action: action){
            Text(title)
                .font(.system(size: 38))
                .foregroundColor(.white)
                .frame(width: 88, height: 88)
                .background(backgroundColor)
                .cornerRadius(44)
        }
    }
}

PlaygroundPage.current.setLiveView(ContentView())
