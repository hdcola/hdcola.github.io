/*:
 在SwiftUI中我们可以使用struct的能力，在View里使用一个SubView简化。请参照一下iPhone的计算器，排布一个键盘。注意，不同的按键的颜色会是不同的哟。
 */
import Foundation
import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    var body: some View {
        HStack{
            CalculatorButton(title: "1", action: {
                print("Tap 1")
            })
            CalculatorButton(title: "2", action: {
                print("Tap 2")
            })
            CalculatorButton(title: "3", action: {
                print("Tap 3")
            })
            CalculatorButton(title: "+", action: {
                print("Tap +")
            })
        }
    }
}

struct CalculatorButton: View{
    let title: String
    let action: () -> Void
    
    var body: some View{
        Button(action: action){
            Text(title)
                .font(.system(size: 38))
                .foregroundColor(.white)
                .frame(width: 88, height: 88)
                .background(Color.secondary)
                .cornerRadius(44)
        }
    }
}

PlaygroundPage.current.setLiveView(ContentView())
