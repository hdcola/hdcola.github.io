/*:
 使用SwiftUI写一个你自己喜欢计算器APP的界面，写出必要的注释让将来的自己和他人容易理解，使用SubView将代码结构良好的分割，使用enum和实现了Hashable的方法来设置界面上不同的显示方法。
*/
import Foundation
import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    var body: some View {
    }
}

PlaygroundPage.current.setLiveView(ContentView())
