/*:
 所有的View及其组件都是一个struct，所以可以使用它的方法（在SwiftUI中叫做修饰符-modifier）来设置各种效果。自己查询一下帮助给Hello World加粗并将字体的颜色更改为红色，再试试利用shadow方法将它加上阴影。
 */
import Foundation
import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    var body: some View {
        Text("Hello World")
            // 设置字体和颜色
            .font(.system(.largeTitle))
            .foregroundColor(.green)
    }
}

PlaygroundPage.current.setLiveView(ContentView())
