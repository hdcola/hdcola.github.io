/*:
 在SwiftUI中有一组叫做Stack的组件专门用于布局(Layout)。这里VStack可以竖排多个组件、HStack可以横排多个组件。请试着用VStack和HStack排列整齐。
 */
import Foundation
import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    var name: String = ""
    var body: some View {
        VStack{
            Text("Hello:\(self.name)")
                .font(.system(.largeTitle))
                .foregroundColor(.green)
            Text("Hello sicheng")
        }
    }
}

PlaygroundPage.current.setLiveView(ContentView())
