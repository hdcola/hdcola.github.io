/*:
 使用VStack在数字键盘上加一个Text显示输入的内容， 大多数View组件都可以  使用`alignment`参数指定`.trailing`用于右对齐，试试怎么把Text右对齐。
*/
import Foundation
import SwiftUI
import PlaygroundSupport

enum CalculatorButtonItem {
    enum Op: String {
        case plus = "+"
        case minus = "-"
        case divide = "÷"
        case multiply = "×"
        case equal = "="
    }
    enum Command: String {
        case clear = "AC"
        case flip = "+/-"
        case percent = "%"
    }
    case digit(Int)
    case dot
    case op(Op)
    case command(Command)
}

extension CalculatorButtonItem: Hashable {
    var title:String{
        switch self {
            case .digit(let value): return String(value)
            case .dot: return "."
            case .op(let op): return op.rawValue
            case .command(let command): return command.rawValue
        }
    }
    var backgroundColor:Color{
        switch self {
            case .digit,.dot: return Color.blue
            case .op: return Color.orange
            case .command: return Color.secondary
        }
    }
    var size:CGSize{
        if self == .digit(0){
            return CGSize(width: 80*2, height: 80)
        }
        return CGSize(width: 80, height: 80)
    }
}

struct ContentView: View {
    let pad: [[CalculatorButtonItem]] = [
        [.command(.clear), .command(.flip),
        .command(.percent), .op(.divide)],
        [.digit(7), .digit(8), .digit(9), .op(.multiply)],
        [.digit(4), .digit(5), .digit(6), .op(.minus)],
        [.digit(1), .digit(2), .digit(3), .op(.plus)],
        [.digit(0), .dot, .op(.equal)]
    ]
    var body: some View {
        VStack(spacing: 8){
            ForEach(pad,id: \.self){ row in
                CalculatorButtonRow(row: row)
            }
        }
    }
}

struct CalculatorButtonRow: View {
    let row: [CalculatorButtonItem]
    
    var body: some View {
        HStack{
            ForEach( row,id:\.self ){ item in
                CalculatorButton(title: item.title,backgroundColor: item.backgroundColor, size: item.size, action: {
                    print("tap \(item.title)")
                })
            }
        }
    }
}

struct CalculatorButton: View{
    let title: String
    let backgroundColor: Color
    let size:CGSize
    let action: () -> Void
    
    var body: some View{
        Button(action: action){
            Text(title)
                .font(.system(size: 38))
                .foregroundColor(.white)
                .frame(width: size.width,height: size.height)
                .background(backgroundColor)
                .cornerRadius(44)
        }
    }
}

PlaygroundPage.current.setLiveView(ContentView())
