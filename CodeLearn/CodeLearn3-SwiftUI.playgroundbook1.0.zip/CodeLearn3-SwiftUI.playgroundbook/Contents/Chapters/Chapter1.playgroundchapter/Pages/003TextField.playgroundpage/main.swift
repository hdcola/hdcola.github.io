/*:
 我们来看看如何使用SwiftUI的TextField组件输入一个内容并设置到变量里去。看懂后， 把这个输入变为姓名、性别、年龄输入，并且在输入后，用一个Text组件显示出你的输入。
 */
import Foundation
import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    // @State代表这是一个SwiftUI的会进行变更和变化后更新显示的变量
    @State var name: String = ""
    @State var password: String = ""
    
    var body: some View {
        // 加入15的间距
        VStack(spacing: 15){
            HStack{
                Text("\(self.name) : \(self.password)")
            }
            HStack{
                Text("昵称：")
                // $name 是传入引用，在函数里可以改变这个变量
                TextField("请输入昵称", text: self.$name)
            }
            .frame(width: 200)
            HStack{
                Text("密码：")
                SecureField("请输入密码",text: self.$password)
            }
            .frame(width: 200)
        }
    }
}

PlaygroundPage.current.setLiveView(ContentView())
