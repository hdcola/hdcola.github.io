/*:
我们将SwiftUI里的ForEach的另一种拿出来学习一下，另外我们将CalculatorButtonRow中的row变为一个创建时指定的内容，这样就简单多了！我帮你已经在ContentView中建立了一个叫pad的常量，想想如何简单的在body中利用pad这种2维数组来布局出一个数字键盘。最后，再看看怎么解决下按键0的大小问题？
*/
import Foundation
import SwiftUI
import PlaygroundSupport

enum CalculatorButtonItem {
    enum Op: String {
        case plus = "+"
        case minus = "-"
        case divide = "÷"
        case multiply = "×"
        case equal = "="
    }
    enum Command: String {
        case clear = "AC"
        case flip = "+/-"
        case percent = "%"
    }
    case digit(Int)
    case dot
    case op(Op)
    case command(Command)
}

// 扩展enmu，支持Hashable用于在View支持ForEach
extension CalculatorButtonItem: Hashable {
    var title:String{
        switch self {
            case .digit(let value): return String(value)
            case .dot: return "."
            case .op(let op): return op.rawValue
            case .command(let command): return command.rawValue
        }
    }
    var backgroundColor:Color{
        switch self {
            case .digit,.dot: return Color.primary
            case .op: return Color.orange
            case .command: return Color.secondary
        }
    }
}

struct ContentView: View {
    let pad: [[CalculatorButtonItem]] = [
        [.command(.clear), .command(.flip),
        .command(.percent), .op(.divide)],
        [.digit(7), .digit(8), .digit(9), .op(.multiply)],
        [.digit(4), .digit(5), .digit(6), .op(.minus)],
        [.digit(1), .digit(2), .digit(3), .op(.plus)],
        [.digit(0), .dot, .op(.equal)]
    ]
    var body: some View {
        VStack(spacing: 8){ // 提高Stack的间距
            CalculatorButtonRow(row:[.command(.clear), .command(.flip), .command(.percent), .op(.divide)])
            CalculatorButtonRow(row:[.digit(1), .digit(2), .digit(3), .op(.plus)])
        }
    }
}

struct CalculatorButtonRow: View {
    let row: [CalculatorButtonItem]
    
    var body: some View {
        HStack{
            // ForEach支持以下这样的方式把每一个item从row里枚举出来
            ForEach( row,id:\.self ){ item in
                CalculatorButton(title: item.title,backgroundColor: item.backgroundColor, action: {
                    print("tap \(item.title)")
                })
            }
        }
    }
}

struct CalculatorButton: View{
    let title: String
    let backgroundColor: Color
    let action: () -> Void
    
    var body: some View{
        Button(action: action){
            Text(title)
                .font(.system(size: 38))
                .foregroundColor(.white)
                .frame(width: 88, height: 88)
                .background(backgroundColor)
                .cornerRadius(44)
        }
    }
}

PlaygroundPage.current.setLiveView(ContentView())
