//#-hidden-code
//
//  main.swift
//
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
/*:
 Class（类）Structure（结构）都可以：
 
 - 定义属性(property)存储值
 - 定义方法(method)提供功能
 - 定义下标(subscript)操作用于访问它们的值
 - 定义构造器(initializer)用于设置初始值
 - 通过扩展(extension)增加功能
 - 遵循协议(protocol)提供标准功能
 
 我们来自己定义一个类和结构，用于说明游戏里一个角色的名字、血和法力。注意，类和结构的名称第一个字符需要大写。可以看到name被定义为`String?`，说明name没有预设的默认值，它被设定为了`没有`(`nil`)。
 
 请在结构和类里，加入攻击力量(attackPower)，为它们设置不同的初始值。我们将会有一堆   虾兵蟹将实例(instance)，让它们互相攻击一次，再show一下，剩下多少hp。
 */
struct CharacterStructure {
    var hp = 10.0
    var mp = 10.0
    var name : String?
}

class CharacterClass{
    var hp = 10.0
    var mp = 10.0
    var name : String?
}

// class和struct都可以初始化
let characterStructure1 = CharacterStructure()
// 设置下characterStructure1的各个属性
let characterClass1 = CharacterClass()
// 设置下characterClass1的各个属性


// struct可以在初始化时通过属性的名称来将初始值传递到成员里去
let characterStructure2 = CharacterStructure(hp: 100.0, name: "蟹将")
// structure无法更改let出来实例(instance)的任何属性值
// characterStructure2.mp = 100

// class无法在没有init方法情况下初始化属性
let characterClass2 = CharacterClass()
// 但是let出来实例(instance)的属性可以更改
characterClass2.name = "虾兵"

// 接下你安排他们相互攻击，看看剩下多少hp
