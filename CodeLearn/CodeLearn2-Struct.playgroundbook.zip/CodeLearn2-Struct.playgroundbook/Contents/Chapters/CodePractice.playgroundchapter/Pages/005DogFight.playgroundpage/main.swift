//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
/*:
请写一个小游戏，人狗大战，2个角色，人和狗，游戏开始后，生成3个人，3条狗，互相混战，人被狗咬了会掉血，狗被人打了也掉血，狗和人的攻击力，具备的功能都不一样。可以尝试一下这样的内容：

- 创建人或狗时的血和攻击力是在一个区间中随机生成的
- 人和狗应该都是动物的子类
- 人在攻击时会随机的用出打、踹、棍三种方法中的一种
- 狗在攻击时会随机的用出咬、扑、撞三种方法中的一种
- 人、狗轮流攻击，每轮随机选择一位攻击对方一位，已经死的不应该被选择到
 */
