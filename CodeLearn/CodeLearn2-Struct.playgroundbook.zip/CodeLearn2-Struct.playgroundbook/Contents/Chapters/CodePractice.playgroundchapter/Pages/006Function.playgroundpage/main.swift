//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
/*:
 之前我们学习了函数，知道把一段重复使用的功能放在一个函数里。但是我们希望让函数处理一段代码后，
 把处理结果得出需要怎么做呢？
  */
// 这个函数把一个数字给它，让它返回数字的字符。
// 在函数声明里使用 -> type 来说明这个函数的返回调用的类型
func iToS(number : Int) -> String {
    let numSting = ["zero","one","two"]
    // 使用return来返回数据
    return numSting[number]
}

// 这就会让s存储iTos函数返回的内容
let s = iToS(number: 1)
show(s)


// 如果我们给入的Int大于3了，我们可以设置返回一个空字符串
func iToS2(number : Int) -> String {
    let numSting = ["zero","one","two"]
    // 使用return来返回数据
    print(numSting.count)
    if number >= numSting.count {
        // 你可以在函数内的任意地方return，这样函数运行到这里返回数据就结束了
        return ""
    }
    return numSting[number]
}

// 这就会让s存储iTos函数返回的内容
let s2 = iToS2(number: 3)
show(s2)
