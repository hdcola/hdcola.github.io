//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
/*:
 我们定义了一个类叫Soldier(士兵)和一个结构General(将军)。接下来我们使用扩展为士兵和将军增加一个方法discribe，返回说明
 */
struct General{
    var hp = 10.0
    var mp = 10.0
    var attackPower = 3.0
    var name : String?
}

class Soldier{
    var hp = 10.0
    var mp = 10.0
    var attackPower = 1.0
    var name : String?
}

// 为General扩展restore方法
extension General{
    func discribe() -> String{
        return "General:\(String(self.name ?? "No Name")),hp:\(self.hp),mp:\(self.mp),attack:\(self.attackPower)"
    }
}

// 请为Soldier也增加discribe方法

let general = General()
show(general.discribe())
let soldier = Soldier()
//show(soldier.discribe())
