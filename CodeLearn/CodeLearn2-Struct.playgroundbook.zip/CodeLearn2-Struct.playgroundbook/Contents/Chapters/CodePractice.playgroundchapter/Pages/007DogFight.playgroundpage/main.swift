//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
/*:

 我们重新写一下人狗大战，这里有几个良好的编程习惯：
 - 在函数里尽可能的只使用参数，不要使用函数外定义的变量
 - 使用函数处理攻击，用它的返回值去更新人或狗的血量
 
重复说明下攻击规则
- 创建人或狗时的血和攻击力是在一个区间中随机生成的
- 人和狗应该都是动物的子类
- 人在攻击时会随机的用出打、踹、棍三种方法中的一种
- 狗在攻击时会随机的用出咬、扑、撞三种方法中的一种
- 人、狗轮流攻击，每轮随机选择一位攻击对方一位，已经死的不应该被选择到
 */

