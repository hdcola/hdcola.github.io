//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
/*:
`\(name)`最前的`\`叫做转义符， 请在String里试试以下转义序列：
 
  - \n 换行
  - \" 字符"
  - \\ 字符\
 
 试着显示以下内容
 
 ```
 今天上午，
 妈妈对我说："快来帮我看看键盘上\在哪里？”
 我帮妈妈找到了\在回车键的上方。
 ```
 
 最后在包含有\的字符串前后加上#看看是什么效果
 */

