//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
/*:
一般我们这样生成一个多行字符串
 
 ```let s = "a\nb\nc"```
 
 来试试这个看看是什么效果
 
 ```
 let s1 = """
 白日依山尽，
 黄河入海流。
 欲穷千里目，
 更上一层楼。
 """
 ```
 */
