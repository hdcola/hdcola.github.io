//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
/*:
String可以使用多种方法连接字符串：
 
  - `+`
  - 在字符串中可以使用 `\(name)`。name 的值会替代占位符。
 
 让我们看看能有多少种方法得到
 
 Hello _______, welcome to _______!
 
 再试着定义下常量和变量，写出这个小故事：
 
 */
let name = ""
let city = "Montreal"

// 试试 +


// 试试\(name)占位符
