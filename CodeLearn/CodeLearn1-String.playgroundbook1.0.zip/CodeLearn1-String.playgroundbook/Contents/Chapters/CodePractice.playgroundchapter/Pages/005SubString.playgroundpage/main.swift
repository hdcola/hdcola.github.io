//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
/*:
写程序试试以下的操作结果都是什么：
 
 - Array(s)[3 ... 5]
 - s.prefix(5)
 - s.suffix(5)
 - s.split(separator: ",")
 
 写个程序把这首诗的顺序写对。
 */
let s = """
更上一层楼
欲穷千里目
黄河入海流
白日依山尽
"""
