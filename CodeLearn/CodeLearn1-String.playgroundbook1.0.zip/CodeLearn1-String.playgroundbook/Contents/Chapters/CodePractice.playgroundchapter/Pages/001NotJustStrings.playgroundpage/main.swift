//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
/*:
可以通过String(Int)来将一个数字转换成为字符串。让我们使用`+`和`\(name)`来写一个小故事：

 今天是<name>重要的日子，所以决定去<city>的商场买一个<price>$的礼物，结果发现商场全场打折<discount>%，最后<name>只用了<price*discount/100>$买到了心爱的礼物欢天喜地的回家了！
 */
let name = ""
let city = "Montreal"
let price = 0
let discount = 90

// 试试 +


// 试试\(name)占位符
