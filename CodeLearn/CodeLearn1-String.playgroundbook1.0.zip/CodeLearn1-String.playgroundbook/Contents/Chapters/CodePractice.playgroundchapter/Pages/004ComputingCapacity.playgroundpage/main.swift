//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
/*:
已知信息如下：
 
 - iPhone 的容量以千兆字节 (GB) 计算。这部 iPhone 有 128GB 存储容量。
 - 1 千兆字节大约为 1,000 兆字节 (MB)。
 - 手机上已经存储了 39GB 资料。
 - 1 分钟的视频占用 150MB 空间。
 
创建一个字符串，告诉用户手机上可以存储几分钟的视频。首先，需要执行计算步骤，然后使用字符串插值来显示答案，格式如下
 
 ```
 你的手机有 XXX GB存储，
 现在已经使用了 XXX GB，
 还有 XXX GB剩余空间，
 你可以再记录 XXX 分钟视频。
```
 
 提示：执行所有计算时以兆字节为单位。
 */
