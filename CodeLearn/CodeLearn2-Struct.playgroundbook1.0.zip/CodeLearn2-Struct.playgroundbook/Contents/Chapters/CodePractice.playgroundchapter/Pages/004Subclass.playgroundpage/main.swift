//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
/*:
 我们定义了一个类叫Soldier(士兵)。但是士兵有两种
 
 - 医疗兵(Medic)：可以heal（医治)士兵，每次医治可以增加5.0的hp，但是增加到10就不能更多了
 - 狙击手(Sniper)：可以snipe（狙击）士兵或将军，一次直接会在attackPower上增加5.0的伤害
 
 看看Medic的示例，请你再增加一个Sniper的子类
  */
class Soldier{
    var hp = 10.0
    var mp = 10.0
    var attackPower = 1.0
    var name : String?
}

// Medic继承Soldier，也就是它是Soldier的子类
class Medic : Soldier {
    var healHp = 5.0
    // 在func的参数后加入inout说明在函数里将会改变参数的值
    func heal( soldier: inout Soldier) {
        soldier.hp += self.healHp
        if soldier.hp > 10 {
            soldier.hp = 10
        }
    }
}

var soldier = Soldier()
soldier.hp = 0
let medic = Medic()
medic.hp = 1
// 对于inout的参数，需要加入&前缀，用于说明传入的参数
medic.heal(soldier: &soldier)
show("soldier:\(soldier.hp) medic:\(medic.hp)")
